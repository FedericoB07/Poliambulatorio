package es1_6_Bogo_Federico;

public class Persona {
	private String nome;
	private String mail;
	private String telefono;

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getMail() {
		return mail;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	/**
	 * @param nome
	 * @param mail
	 * @param telefono
	 */
	public Persona(String nome, String mail, String telefono) {

		this.nome = nome;
		this.mail = mail;
		this.telefono = telefono;
	}

	@Override
	public String toString() {
		return " nome=" + nome + ", mail=" + mail + ", telefono=" + telefono + "";
	}

}
