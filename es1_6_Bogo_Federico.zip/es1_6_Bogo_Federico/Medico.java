package es1_6_Bogo_Federico;

/**
 * Classe Medico che estende Persona, rappresenta un medico con attributi
 * specifici.
 */
public class Medico extends Persona {

	private String codiceMedico;
	private String studio;
	private int codiceBranca;

	/**
	 * Costruttore della classe Medico
	 * 
	 * @param nome         Nome del medico
	 * @param email        Email del medico
	 * @param telefono     Telefono del medico
	 * @param codiceMedico Codice univoco del medico
	 * @param studio       Studio del medico
	 * @param codiceBranca Codice della branca specialistica
	 */
	public Medico(String nome, String email, String telefono, String codiceMedico, String studio, int codiceBranca) {
		super(nome, email, telefono);
		this.codiceMedico = codiceMedico;
		this.studio = studio;
		this.codiceBranca = codiceBranca;
	}

	/**
	 * Restituisce il codice del medico.
	 * 
	 * @return codiceMedico
	 */
	public String getCodiceMedico() {
		return codiceMedico;
	}

	/**
	 * Imposta il codice del medico.
	 * 
	 * @param codiceMedico codice univoco del medico
	 */
	public void setCodiceMedico(String codiceMedico) {
		this.codiceMedico = codiceMedico;
	}

	/**
	 * Restituisce lo studio del medico.
	 * 
	 * @return studio
	 */
	public String getStudio() {
		return studio;
	}

	/**
	 * Imposta lo studio del medico.
	 * 
	 * @param studio studio del medico
	 */
	public void setStudio(String studio) {
		this.studio = studio;
	}

	/**
	 * Restituisce il codice della branca specialistica.
	 * 
	 * @return codiceBranca
	 */
	public int getCodiceBranca() {
		return codiceBranca;
	}

	/**
	 * Imposta il codice della branca specialistica.
	 * 
	 * @param codiceBranca codice della branca specialistica
	 */
	public void setCodiceBranca(int codiceBranca) {
		this.codiceBranca = codiceBranca;
	}

	/**
	 * Restituisce la descrizione della branca specialistica.
	 * 
	 * @return Descrizione della branca specialistica
	 */
	public String getDescrizioneBranca() {
		return Branca.getBranca(codiceBranca);
	}

	/**
	 * Override del metodo toString per rappresentare i dati del medico.
	 * 
	 * @return Stringa con i dettagli del medico
	 */
	@Override
	public String toString() {
		return "medico " + super.toString() + "codice" + getCodiceMedico() + "studio" + getStudio() + "branca"
				+ getCodiceBranca();
	}
}
