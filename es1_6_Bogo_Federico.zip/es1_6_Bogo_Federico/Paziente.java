package es1_6_Bogo_Federico;

/**
 * Classe Paziente che estende Persona, rappresenta un paziente con un gruppo di
 * prestazioni specifico.
 */
public class Paziente extends Persona {

	private String indirizzo; // Indirizzo del paziente
	private String citta; // Città del paziente
	private Prestazione prestazione; // Prestazione associata al paziente

	/**
	 * Costruttore della classe Paziente
	 * 
	 * @param nome        Nome del paziente
	 * @param email       Email del paziente
	 * @param telefono    Telefono del paziente
	 * @param indirizzo   Indirizzo del paziente
	 * @param citta       Città del paziente
	 * @param prestazione Prestazione associata al paziente
	 */
	public Paziente(String nome, String email, String telefono, String indirizzo, String citta,
			Prestazione prestazione) {
		super(nome, email, telefono);
		this.indirizzo = indirizzo;
		this.citta = citta;
		this.prestazione = prestazione;
	}

	/**
	 * Restituisce l'indirizzo del paziente.
	 * 
	 * @return indirizzo
	 */
	public String getIndirizzo() {
		return indirizzo;
	}

	/**
	 * Imposta l'indirizzo del paziente.
	 * 
	 * @param indirizzo Indirizzo del paziente
	 */
	public void setIndirizzo(String indirizzo) {
		this.indirizzo = indirizzo;
	}

	/**
	 * Restituisce la città del paziente.
	 * 
	 * @return citta
	 */
	public String getCitta() {
		return citta;
	}

	/**
	 * Imposta la città del paziente.
	 * 
	 * @param citta Città del paziente
	 */
	public void setCitta(String citta) {
		this.citta = citta;
	}

	/**
	 * Restituisce la prestazione associata al paziente.
	 * 
	 * @return prestazione
	 */
	public Prestazione getPrestazione() {
		return prestazione;
	}

	/**
	 * Imposta una prestazione associata al paziente.
	 * 
	 * @param prestazione Prestazione da associare
	 */
	public void setPrestazione(Prestazione prestazione) {
		this.prestazione = prestazione;
	}

	/**
	 * Override del metodo toString per rappresentare i dati del paziente.
	 * 
	 * @return Stringa con i dettagli del paziente e della prestazione
	 */
	@Override
	public String toString() {
		String info = "Paziente [nome=" + getNome() + ", email=" + getMail() + ", telefono=" + getTelefono()
				+ ", indirizzo=" + indirizzo + ", citta=" + citta + "]\n";

		if (prestazione != null) {
			info += "Prestazione:\n";
			info += "- " + prestazione.toString() + "\n";
		} else {
			info += "Nessuna prestazione associata.\n";
		}

		return info;
	}
}
