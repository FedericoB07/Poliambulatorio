package es1_6_Bogo_Federico;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Persona p1 = new Persona("luza", "luzapagluza@gmail.fro", "3334445678");
		System.out.println(p1);
		Medico m1 = new Medico("luza", "lil", "3333", "s", "33", 2);
		System.out.println(m1);

	}

}
