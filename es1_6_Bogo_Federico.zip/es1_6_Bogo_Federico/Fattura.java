package es1_6_Bogo_Federico;

public class Fattura {

}
