package es1_6_Bogo_Federico;

/**
 * Classe Branca per la gestione delle varie branche specialistiche
 * 
 * @author ignazio pinto
 *
 */
public class Branca {
	public static final int RADIOLOGIA = 18;
	public static final int ODONTOIATRIA = 19;
	public static final int UROLOGIA = 20;
	public static final int PEDIATRIA = 21;

	/**
	 * Restituisce la descrizione della branca specialistica corrispondente
	 * 
	 * @param branca codice della branca specialistica
	 * @return la descrizione della branca specialistica
	 */
	public static String getBranca(int branca) {
		String debranca = "Non Associata";
		switch (branca) {
		case 18:
			debranca = "Radiologia";
			break;
		case 19:
			debranca = "Odontoiatria";
			break;
		case 20:
			debranca = "Urologia";
			break;
		case 21:
			debranca = "Pediatria";
			break;
		default:
			break;
		}
		return debranca;
	}

}
