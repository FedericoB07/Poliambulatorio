package es1_6_Bogo_Federico;

/**
 * Classe che rappresenta una Prestazione erogata nel poliambulatorio. Contiene
 * informazioni sul tipo, costo e IVA della prestazione.
 * 
 * @author Bogo Federico
 */
public class Prestazione {
	private String codice;
	private String descrizione;
	private int branca;
	private double prezzoUnitario;
	private double percentualeIVA;

	/**
	 * Costruttore per inizializzare una Prestazione.
	 * 
	 * @param codice         Codice univoco della prestazione
	 * @param descrizione    Descrizione della prestazione
	 * @param branca         Branca specialistica associata (codice)
	 * @param prezzoUnitario Prezzo unitario della prestazione
	 * @param percentualeIVA Percentuale IVA applicata
	 */
	public Prestazione(String codice, String descrizione, int branca, double prezzoUnitario, double percentualeIVA) {
		this.codice = codice;
		this.descrizione = descrizione;
		this.branca = branca;
		this.prezzoUnitario = prezzoUnitario;
		this.percentualeIVA = percentualeIVA;
	}

	/**
	 * Getter e Setter
	 * 
	 * @return
	 */
	public String getCodice() {
		return codice;
	}

	public void setCodice(String codice) {
		this.codice = codice;
	}

	public String getDescrizione() {
		return descrizione;
	}

	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}

	public int getBranca() {
		return branca;
	}

	public void setBranca(int branca) {
		this.branca = branca;
	}

	public double getPrezzoUnitario() {
		return prezzoUnitario;
	}

	public void setPrezzoUnitario(double prezzoUnitario) {
		this.prezzoUnitario = prezzoUnitario;
	}

	public double getPercentualeIVA() {
		return percentualeIVA;
	}

	public void setPercentualeIVA(double percentualeIVA) {
		this.percentualeIVA = percentualeIVA;
	}

	/**
	 * Calcola il prezzo totale della prestazione (inclusa IVA).
	 * 
	 * @return Prezzo totale con IVA inclusa.
	 */
	public double calcolaPrezzoConIVA() {
		return prezzoUnitario + (prezzoUnitario * percentualeIVA / 100);
	}

	/**
	 * 
	 */
	@Override
	public String toString() {
		return "codice:" + codice + ", descrizione:" + descrizione + ", branca:" + branca + ", prezzoUnitario:"
				+ prezzoUnitario + ", percentualeIVA:" + percentualeIVA + ", importo:" + calcolaPrezzoConIVA();

	}
}
